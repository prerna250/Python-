a=eval(input("enter a list="))
b=[]
x=sum(a)
b.append(x)
print("the sum of the list is=",b)
