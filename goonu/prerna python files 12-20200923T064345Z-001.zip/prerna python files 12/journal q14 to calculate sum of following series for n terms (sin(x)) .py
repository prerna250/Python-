x=int(input("input value of x="))
n=int(input("input value of n="))
def fact(j):
    fact=1
    for x in range(1,j+1):
        fact=fact*n
    return fact
r=0
for h in range(3,n+1,4):
    y=(-1)*x**(h)
    q=fact(h)
    r=r+y/q
q=0
for j in range(1,n+1,4):
    num=x**(j)
    deno=fact(j)
    q=q+num/deno
print(r+q)
