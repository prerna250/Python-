import matplotlib.pyplot as p
mar=[130,130,150,200,130]
zones=["north","south","east","west","central"]
p.title("rainfall in the month of march")
p.pie(mar,labels=zones,autopct="%1.1f%%",explode=[0,0,0.3,0,0],colors=['b','g','m','c','r'])
p.legend(zones)
p.show()
