s=input("enter =")
c=input("character=")
count=0
for x in s:
    if x==c:
        count=count+1
print(count)

