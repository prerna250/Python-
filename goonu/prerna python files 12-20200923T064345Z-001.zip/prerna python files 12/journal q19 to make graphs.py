import matplotlib.pyplot as p
import numpy as np
zones=["north","south","east","west","central"]
jan=[140,160,140,180,110]
feb=[130,200,180,150,160]
march=[130,130,150,200,130]
april=[190,200,170,120,110]
def pie():
    p.pie(march,labels=zones,autopct="%1.2f%%",explode=[0,0,0.2,0,0],colors=["blue","green","pink","yellow","red"])
    p.legend()
    p.show()
def bargraph():
    x=np.arange(len(jan))
    p.bar(x,jan,color="red",width=0.2,label="jan")
    p.bar(x+0.2,feb,color="blue",width=0.2,label="feb")
    p.bar(x+0.4,march,color="yellow",width=0.2,label="march")
    p.bar(x+0.6,april,color="green",width=0.2,label="april")
    p.title("rainfall in different zones")
    p.xlabel("zones")
    p.ylabel("rainfall in months")
    p.legend()
    p.xticks(x,zones)
    p.show()
def line():
    p.plot(zones,jan,"r--",label="jan",marker="d",markeredgecolor="black")
    p.plot(zones,feb,"y--",label="feb",marker="h",markeredgecolor="brown")
    p.plot(zones,march,"m-",label="march",marker="o",markeredgecolor="blue")
    p.plot(zones,april,"b:",label="april",marker="s",markeredgecolor="red")
    p.xlabel("zones")
    p.ylabel("rainfall in months")
    p.title("rainfall in different zones")
    p.legend()
    p.show()
while True:
    menu=int(input("enter 1)to make a line chart,2)to make a barchart,3)to make a pie chart="))
    if menu==1:
        line()
    elif menu==2:
        bargraph()
    elif menu==3:
        pie()
    else:
        break

