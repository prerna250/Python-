l=[]
def add():
    z=int(input("enter total number  of elements in list="))
    for x in range(z):
        n=int(input("enter a number="))
        l.append(n)
def insert():
    n=int(input("enter position to insert="))
    f=int(input("enter a number to insert="))
    l.insert(n,f)
    print(l)
def delete():
    for x in l:
        y=l.count(x)
        if y>1:
            l.remove(x)
        elif y==1:
            print(x,"element cannot be deleted")
    print(l)
def merge():
    l1=eval(input("enter a list="))
    for y in l1:
        l.append(y)
    print(l)
def sort():
    for i in range(len(l)):
        for x in range(0,len(l)-1):
            if l[x]>l[x+1]:
                l[x],l[x+1]=l[x+1],l[x]
    print(l)        
def swap(l):
    if len(l)%2==0:
        n=len(l)//2
        l2=l[n:]+l[:n]
    else:
        n=len(l)//2
        l2=l[n+1:]+l[n:n+1]+l[:n]
    print("swapped list=",l2)
def lsearch():
    j=eval(input("enter a number to search="))
    for x in range(len(l)):
        if l[x]==j:
            print("position of element=",x)
            break
    else:
        print("element not found")
while True:
    menu=int(input("enter 1) to add new element,2) to insert one element at given location,3) to delete,4) to merge one list,5) to sort,6)to swap first half with second,7) to search an element,8) to stop=="))
    if menu==1:
        add()
    elif menu==2:
        insert()
    elif menu==3:
        delete()
    elif menu==4:
        merge()
    elif menu==5:
        sort()
    elif menu==6:
        swap(l)
    elif menu==7:
        lsearch()
    elif menu==8:
        break
