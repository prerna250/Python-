#binary search using recursion
m=eval(input("enter a list="))
b=0
end=len(m)-1
e=int(input("enter element to be searched="))
def rbsearch(m,b,end,e):
    mid=(b+end)//2
    if e==m[mid]:
        print("element found at=",mid)
        return
    elif e<m[mid]:
        end=mid-1
        rbsearch(m,b,end,e)
    elif e>m[mid]:
        b=mid+1
        rbsearch(m,b,end,e)
rbsearch(m,b,end,e)
print("thankyou")
        
