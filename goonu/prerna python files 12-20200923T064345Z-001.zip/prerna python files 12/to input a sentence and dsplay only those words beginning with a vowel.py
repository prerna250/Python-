a=input('enter str=')
b=a.split()
c=['a','e','i','o','u']
for x in b:
    for y in c:
        if x[0]==y:
            print(x)
        
