top=None
stack=[]
def push(ele):
    global top
    stack.append(ele)
    top=len(stack)-1
    print(stack)

def pop():
    global top
    if stack == []:
        print("Stack is emplty!!")
    else:
        stack.pop()
        if stack == []:
            top=None
        else:
            top = top-1
    print(stack)
def peek():
    print("topmost element",stack[top])
def display():
    if stack==[]:
        print("stack is empty")
    else:
        for x in range(top,-1,-1):
            print(stack[x],end="\n")
            
while True:
    a=int(input("1.push\n2.pop\n3.peek\n4.display\n5.end="))
    if a==1:
        ele=int(input("enter a number to be pushed="))
        push(ele)
    elif a==2:
        pop()
    elif a==3:
        peek()
    elif a==4:
        display()
    else:
        print("oki")
        break
