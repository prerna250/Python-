#implementation of queue
queue=[]
rear=None
front=None
def enqueue(queue):        #to append element at end
    global rear
    global front
    m=int(input("enter element to be added="))
    queue.append(m)
    front=0
    rear=len(queue)-1
    print(queue)
def dqueue(queue):         #to delete element of first position
    global rear
    global front
    if queue==[]:
        print("queue is empty")
        front=rear=none
    else:
        queue.pop(0)
        rear=len(queue)-1
    print(queue)
def peek(queue):        #to display topmost element
    print("first element in queue=",queue[front])
def display(queue):     #to display all the elements
    if queue==[]:
        print("it is empty")
    else:
        for x in range(front,rear+1,1):
            print(queue[x])
while True:             #main
    menu=int(input("enter 1) to insert,2) to delete,3) to peek,4) to display,5) to exit="))
    if menu==1:
        enqueue(queue)
    elif menu==2:
        dqueue(queue)
    elif menu==3:
        peek(queue)
    elif menu==4:
        display(queue)
    elif menu==5:
        break
