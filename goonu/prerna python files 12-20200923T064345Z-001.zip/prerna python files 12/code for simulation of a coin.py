import random
a=int(input("enter chances="))
for x in range(0,a):
    b=int(input("1(heads) or 2(tails)="))
    c=random.randint(1,2)
    if b==c:
        print("correct")
    else:
        print("sorry")

