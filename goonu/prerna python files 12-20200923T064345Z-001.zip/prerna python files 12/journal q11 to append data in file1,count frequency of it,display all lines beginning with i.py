def append():
    fread=open("data2.txt","r")
    fwrite=open("file1.txt","a")
    for x in fread:
        fwrite.write(x+"\n")
    fread.close()
    fwrite.close()
    fread=open("file1.txt","r")
    print(fread.read())
    fread.close()
def count():
    f=open("file1.txt","r")
    p=f.read()
    p=p.lower()
    x=p.split()
    a=x.count("it")
    print("frequency of word it is=",a)
    f.close()
def iline():
    fin=open("file1.txt")
    while True:
        t=fin.readline()
        if len(t)==0:
            break
        if t[0]=="I" or t[0]=="i":
            print(t)
    fin.close()
while True:
    menu=int(input(" 1.for appending contents of data2.txt to file1.txt and display 2.for counting frequeny of word it 3.for dispalying lines from file1.txt except lines starting with i 4.to stop="))
    if menu==1:
        append()
    elif menu==2:
        count()
    elif menu==3:
        iline()
    elif menu==4:
        break




    
    
        
    
