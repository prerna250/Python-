l=eval(input("enter the list="))
def maxi(l):
    if len(l)==1:
        return l[0]
    return max(l[0],maxi(l[1:]))
print("the maximum number is",maxi(l))
