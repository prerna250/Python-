def pnum(a):
    s1=str(a)
    c=s1[::-1]
    if c==a:
        print("number is palindrome")
    else:
        print("number is not palindrome")
def strpal(a):
    m=a[::-1]
    if m==a:
        print("palindrome")
    else:
        print("not palindrome")
while True:
    z=int(input("1. number palindrome 2. string palindrome"))
    if z==1:
        a=input("number=")
        pnum(a)
    else:
        a=input("enter a string=")
        strpal(a)
