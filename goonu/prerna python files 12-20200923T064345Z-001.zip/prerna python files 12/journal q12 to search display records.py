import pickle
def writef():
    b=open("phonedir.dat","ab")
    while True:
        c=int(input("enter 1 to append,0 to stop="))
        if c==1:
            a={}
            d=input("enter name=")
            e=int(input("enter phone number="))
            a[d]=e
            pickle.dump(a,b)
        else:
            break
    
    b.close()
writef()
def read():
        b=open("phonedir.dat","rb")
        try:
            while True:
                p=pickle.load(b)
                print(p)
        except EOFError:
            pass
        b.close()

def search():
    b=open("phonedir.dat","rb")
    n=input("enter name to be searched=")
    try:
        while True:
            d=pickle.load(b)
            if n in d:
                print(d)
    except EOFError:
        pass

def searchno():
    b=open("phonedir.dat","rb")
    n=int(input("enter number to be searched="))
    try:
        while True:
            d=pickle.load(b)
            if n in d.values():
                print(d)
    except EOFError:
        pass


while True:
    menu=int(input("enter 2)to display all records, 3)to search by name, 4)to search by number,5)to stop="))
    if menu==2:
        read()
    elif menu==3:
        search()
    elif menu==4:
        searchno()
    elif menu==5:
        break
        
        
                    



