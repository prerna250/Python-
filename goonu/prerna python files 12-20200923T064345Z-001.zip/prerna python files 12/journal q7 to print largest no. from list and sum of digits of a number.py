while True:
    menu=int(input("enter l.largest element from the list,2.sum of digits="))
    #menu=int(input("enter your choice="))
    if menu==1:
        def largest(m,p,l):
            if p==0:
                return l
            if p>0:
                if m[p]>l:
                    l=m[p]
            return largest(m,p-1,l)
        m=eval(input("enter a list="))
        l=m[0]
        s=len(m)-1
        l=largest(m,s,l)
        print("largest number is=",l)
    if menu==2:
        def sumdigit(n):
            if n==0:
                return n
            else:
                return(n%10+sumdigit(n//10))
        n=eval(input("enter a number="))
        print(sumdigit(n))
    
