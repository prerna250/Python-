def write():
    f=open("data.txt","w")
    for x in range(0,5):
        n=input("enter a sentence=")
        h=n+"\n"
        f.write(h)
def count():
    f=open("data.txt","r")
    b=f.readlines()
    count=0
    for x in b:
        for y in x:
            if y=="a" or y=="e"or y=="i"or y=="o"or y=="u":
                    count=count+1
    print("no. of vowels=",count)
def sumno():
    f=open("data.txt","r")
    x=f.readlines()
    sum=0
    for c in x:
        for z in c:
            if z.isdigit():
                sum=sum+int(z)
    print("sum of numbers=",sum)
def upper():
    f=open("data.txt","r")
    x=f.readlines()
    for c in x:
        if c.islower():
            c=c.upper()
        print(c,end="")
while True:
    menu=int(input("1.for writing lines in file 2. for counting vowels 3.for finding sum of numbers 4.for printing the lines in upper case 5.to stop="))
    if menu==1:
        write()
    elif menu==2:
        count()
    elif menu==3:
        sumno()
    elif menu==4:
        upper()
    elif menu==5:
        break
    
