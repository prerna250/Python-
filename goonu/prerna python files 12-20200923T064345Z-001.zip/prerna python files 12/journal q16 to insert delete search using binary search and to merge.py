import bisect
def bubblesort(l):
    leng=len(l)
    for x in range(leng-1):
        for y in range(leng-1-x):
            if l[y]>l[y+1]:
                l[y],l[y+1]=l[y+1],l[y]
    return(l)

def insert(l,n):
    bisect.insort(l,n)
    print('New list - ',l)

def delete(l,n):
    for x in range(len(l)):
        if l[x]==n:
            l=l[:x]+l[x+1:]
            break
    else:
        print('Element not found.')
    print('New list - ',l)

def merge(l1,l2):
    for x in l2:
        bisect.insort(l1,x)
    print('New list - ',l1)

def search(l,n):
    c=0
    b=0
    e=len(l)-1
    while b<=e:
        m=(b+e)//2
        if l[m]<n:
            b=m+1
        elif l[m]>n:
            e=m-1
        elif l[m]==n:
            pos=m
            c=1
            break
    if c==1:
        print('Element found at index - ',pos)
    else:
        print('Element not found !!')


    

l=eval(input('Enter a list - '))
l1=bubblesort(l)
print('Sorted list - ',l1)
while True:
    print()
    c=int(input('1.Add element\n2.Delete element\n3.Merge two sorted lists(third list remains constant)\n4.Binary search\nEnter your choice - '))
    print()
    if c==1:
        n=int(input('enter element to be added- '))
        insert(l1,n)
    elif c==2:
        n=int(input('enter element to be deleted - '))
        delete(l1,n)
    elif c==3:
        l2=eval(input('Enter list to be merged - '))
        l2=bubblesort(l2)
        merge(l1,l2)
    elif c==4:
        n=int(input('Enter no. to searched - '))
        search(l1,n)
    else:
        break

