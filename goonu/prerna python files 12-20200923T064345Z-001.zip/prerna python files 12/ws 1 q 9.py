a=eval(input("enter a list="))
b=list(a)
c=[]
for x in range(len(b)):
    if x%2==0:
        b.remove(x)
    else:
        c.append(x)
print(c)
