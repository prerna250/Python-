def fact(n):
    if n<1:
        return 1
    else:
        return fact(n-1)*n
def fibo(num):
    if num<2:
        return num
    else:
        return fibo(num-1)+fibo(num-2)
while True:
    menu=int(input("enter 1.for printing factorial series 2.for printing fibonacci series 3.to stop="))
    if menu==1:
        n=int(input("enter a number="))
        print(fact(n))
    elif menu==2:
        n=int(input("enter terms="))
        for a in range(n):
            print(fibo(a),end=",")
    elif menu==3:
        break
