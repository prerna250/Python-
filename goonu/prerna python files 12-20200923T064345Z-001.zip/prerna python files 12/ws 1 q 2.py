a=eval(input("enter a list of numbers="))
b=list(a)
m=max(b)
print("largest number from list is=",m)
