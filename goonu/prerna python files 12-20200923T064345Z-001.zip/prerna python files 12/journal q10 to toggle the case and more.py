def toggle():
    a=open("data2.txt","r")
    for x in a:
        print(x.swapcase())
    a.close()
def search():
    f=open("data2.txt","r")
    q=open("new data.txt","w")
    e=f.readlines()
    for i in e:
        p=i.lower().split()
        if "the" in p:
            q.write(i)
    f.close()
    q.close()
    q=open("new data.txt","r")
    print(q.read())
    q.close()
def copy():
    f=open("data2.txt")
    p=f.readlines()
    x=input("enter character=")
    for a in p:
        if x in a:
            print(a)
    f.close()

while True:
    a=int(input("choose an option:1)invert case of the data 2)display lines with 'the' in them 3)display lines with 'x' in them 4)to stop:"))
    if a==1:
        toggle()
    elif a==2:
        search()
    elif a==3:
        copy()
    else:
        break
    
    
