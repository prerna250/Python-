import mysql.connector as con
obj=con.connect(host="localhost",user="root",password="tiger",database="prerna")
cur=obj.cursor()
def one():
    a="create table games(gcode int(3),gamename char(20),number int,prizemoney int)"
    cur.execute(a)
    obj.commit()
def two():
    cur.execute("insert into games values({},'{}',{},{})".format(101,'Carrom',2,5000))
    cur.execute("insert into games values({},'{}',{},{})".format(102,'Badminton',2,12000))
    cur.execute("insert into games values({},'{}',{},{})".format(103,'TTennis',4,8000))
    cur.execute("insert into games values({},'{}',{},{})".format(105,'Chess',2,9000))
def three():
    cur.execute("select max(prizemoney),min(prizemoney) from games")
    print(cur.fetchall())
def four():
    cur.execute("select * from games where number=2 order by prizemoney")
    print(cur.fetchall())
def five():
    cur.execute("update games set prizemoney=(prizemoney+0.1*prizemoney) where gcode in(101,105)")
    obj.commit()
def six():
    cur.execute("select gamename from games where gamename like 'c%'")
    print(cur.fetchall())
def seven():
    cur.execute("delete from games where gcode=102")
    obj.commit()
def eight():
    cur.execute("select sum(prizemoney) from games group by number")
    print(cur.fetchall())
def nine():
    cur.execute("Select * from games where prizemoney<10000")
    print(cur.fetchall())
def ten():
    cur.execute("select * from games order by gamename")
    print(cur.fetchall())
   
#one()
#two()
while True:
    print("\n1.Three\n2.Four\n3.Five\n4.Six\n5.Seven\n6.Eight")
    z=int(input("Enter Choice:"))
    if z==1:
        three()
    elif z==2:
        four()
    elif z==3:
        five()
    elif z==4:
        six()
    elif z==5:
        seven()
    elif z==6:
        eight()
    else:
        break
        
#textfile

def write():
    with open("file1.txt",'w') as fobj:
        fobj.write("Hello My Name Is Mansi I Am A Student Of DAV International School ,Kharghar")
        fobj.write("I Am A PCMCS Student IN Class 12th Standard ")
def read():
        with open("file1.txt",'r') as fobj:
            s=fobj.read()
            c=0
            for x in range(0,len(s)):
                let=s[x]
                v=["a","e","i","o","u","A","E","I","O","U"]
                if let in v:
                    c=c+1
            print("Number Of Vowels Are :",c)

write()
read()
