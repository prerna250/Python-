a=input("enter=")
b=len(a)
count=0
c=["a","e","i",'o','u','A','E','I','O','U']
for x in range(0,b):
    for y in range(0,10):
        if a[x]==c[y]:
            count=count+1
print(count)
