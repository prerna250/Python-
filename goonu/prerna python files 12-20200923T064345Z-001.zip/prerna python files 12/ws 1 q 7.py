a=eval(input("enter list 1="))
b=eval(input("enter list 2="))
for x in range(0,len(a)):
    for y in range(0,len(b)):
        if a[x]==b[y]:
            print("true")
            break
        

        
    
