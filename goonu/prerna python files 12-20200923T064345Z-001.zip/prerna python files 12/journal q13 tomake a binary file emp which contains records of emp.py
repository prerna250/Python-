import pickle
def append():
    x=1
    while x==1:
        w=open("emp.dat","ab")
        empno=int(input("enter the employee number="))
        empname=input("enter employee name=")
        age=int(input("enter age of employee="))
        salary=int(input("enter salary="))
        list1=[empno,empname,age,salary]
        pickle.dump(list1,w)
        n=int(input("enter 1 to append more 2)to stop:"))
        x=x*n
def read():
    w=open("emp.dat","rb")
    try:
        while True:
            d=pickle.load(w)
            print(d)
    except EOFError:
        pass
    w.close()
def age():
    x=int(input("enter age="))
    w=open("emp.dat","rb")
    import pickle
    try:
        while True:
            data = pickle.load(w)
            if data[2] > x:
                print(data)
    except EOFError:
        pass
    w.close()    
def searchname():
    x=input("enter name to be searched=")
    w=open("emp.dat","rb")
    import pickle
    flag=0
    try:
        while True:
            data = pickle.load(w)
            if data[1]==x:
                print(data)
                flag=flag+1            
    except EOFError:
        pass
    if flag==0:
        print("record not found")    
while True:
    menu=int(input("1:append record,2) to read all contents,3)print as per age,4) display record as per name,5) quit="))
    if menu==1:
        append()
    if menu==2:
        read()
    if menu==3:
        age()
    if menu==4:
        searchname()
    if menu==5:
        break


