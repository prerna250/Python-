def primeno(num,i):
    if i==1:
        return 1
    else:
        if num%i==0:
            return 0
        else:
            return(primeno(num,i-1))
def sumof(num):
    if num==1:
        return 1
    else:
        return(num+sumof(num-1))    
while True:
    menu=int(input("1.sum of N numbers\n2.check if the number is prime or not\n3.to stop="))
    if menu==1:
        num=int(input("enter N="))
        print(sumof(num))
    elif menu==2:
        num=int(input("enter a number="))
        check=primeno(num,num//2)
        if check==1:
            print(num,"is a prime number")
        else:
            print(num,"is not a prime number")
    elif menu==3:
        break
