import random
def dice():
    return random.randint(1,6)
print(dice())
