b=[]
top=None
def push(ele):
    global top
    b.append(ele)
    top=len(b)-1
def pop():
    global top
    if b==[]:
        print("stack is empty")
    else:
        b.pop()
        if b==[]:
            top=None
        else:
            top=top-1
def peek():
    print("topmost element from stack=",b[top])
def display():
    if b==[]:
        print("stack is empty")
    else:
        for x in range(top,-1,-1):
            print(b[x],end="\n")
while True:
    menu=int(input("enter 1 to push,2 to pop,3 to peek,4 to display,5 to exit=="))
    if menu==1:
        m=int(input("enter an element to push="))
        push(m)
    elif menu==2:
        pop()
    elif menu==3:
        peek()
    elif menu==4:
        display()
    elif menu==5:
        break
    
    
