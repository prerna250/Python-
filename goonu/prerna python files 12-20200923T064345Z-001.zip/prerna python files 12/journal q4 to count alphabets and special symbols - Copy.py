def alphabets(x):
    a=0
    b=0
    c=0
    for y in x:
        if y.isalpha():
            a+=1
        elif y.isdigit():
            b+=1
        elif not y.isalnum():
            c+=1
    print("1)number of alphabets=",a)
    print("2)number of special characters=",c)
    print("3)number of digits=",b)
def capital(x):
    l=[]
    s=""
    m=x.split()
    for y in m:
        a=y.capitalize()
        l.append(a)
    for z in l:
        s+=z+" "
    print(s)
def reverse(x):
    s=""
    l=[]
    a=x.split()
    for y in a:
        s+=y[::-1]
    print(s)
x=input("enter a sentence=")
while True:
    k=int(input("caps,charrr,rever"))
    if k==1:
        capital(x)
    elif k==2:
        alphabets(x)
    else:
        reverse(x)
     
        
