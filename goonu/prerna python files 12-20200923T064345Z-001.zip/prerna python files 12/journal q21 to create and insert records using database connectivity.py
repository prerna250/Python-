import mysql.connector as con
obj=con.connect(host="localhost",user="root",password="tiger",database="prerna")
cur=obj.cursor()
def table():      #create table
    s="create table customer(custid char(20) primary key,custname char(20),address char(30),panno int)"
    t="create table accounts(accno int,acctype char(1),custid char(4),balance float)"
    cur.execute(s)
    cur.execute(t)
def icustomer():
    q="select * from customer"
    cur.execute(q)
    p=cur.fetchall()
    i="c"+str(cur.rowcount+1)
    n=input("enter customer name=")
    d=input("enter address=")
    p=int(input("enter pan number="))
    s="insert into customer values('{}','{}','{}','{}')".format(i,n,d,p)
    cur.execute(s)
    obj.commit()
def iaccounts():     
    q="select * from accounts"
    cur.execute(q)
    p=cur.fetchall()
    acc=cur.rowcount+1
    i=input("enter customer id=")
    t=input("enter account type (s/c)=")
    if t=='s' or t=='S':
        print("enter balance more than 1000")
    b=int(input("enter balance="))
    s="insert into accounts values({},'{}','{}',{})".format(acc,t,i,b)
    cur.execute(s)
    obj.commit()

def showall():      
    q="select * from customer natural join accounts"
    cur.execute(q)
    data=cur.fetchall()
    print("custid","name","address","pan no","acc no","acc type","balance")
    for x in data:
        print (x)
def searchcust():
    name=input("enter name to search=")
    q="select * from customer natural join accounts"
    cur.execute(q)
    data=cur.fetchall()
    print("custid","name","address","pan no","acc no","acc type","balance")
    for x in data:
        if x[1]==name:
            print(x)
def searchacc():
    acc=input("enter name to search=")
    q="select * from customer natural join accounts"
    cur.execute(q)
    data=cur.fetchall()
    print("custid","name","address","pan no","acc no","acc type","balance")
    for x in data:
        if x[1]==acc:
            print(x)
def daccount():
    q="select * from accounts"
    cur.execute(q)
    data=cur.fetchall()
    print("acc no","acc type","custid","balance")
    for x in data:
        print(x)
def dcustomer():
    q="select * from customer"
    cur.execute(q)
    data=cur.fetchall()
    print("custid","custname","address","pan no")
    for x in data:
        print(x)
def modify():
    while True:
        menu=int(input("\n1)to modify the name\n2)to modify address\n3)to modify panno\n4)to modify entire record\n5)to end modification\nenter:"))
        if menu==1:
            a=input("enter custid to search=")
            name=input("enter new customer name=")
            q="update customer set custname='{}' where custid='{}'".format(name,a)
            cur.execute(q)
            obj.commit()
        elif menu==2:
            a=input("enter custid=")
            add=input("enter new address=")
            q="update customer set address='{}' where custid='{}'".format(add,a)
            cur.execute(q)
            obj.commit()
        elif menu==3:
            a=input("enter custid=")
            new=input("enter new panno=")
            q="update customer set panno={} where custid='{}'".format(new,a)
            cur.execute(q)
            obj.commit()
        elif menu==4:
            i=input("enter custid=")
            newname=input("enter new name=")
            newadd=input("enter new address=")
            newpanno=input("enter new panno=")
            q="update customer set custname='{}',address='{}',panno={} where custid='{}'".format(newname,newadd,newpanno,i)
            cur.execute(q)
            obj.commit()
        elif menu==5:
            break
def deposit():
    accno=int(input("enter account number="))
    amt=int(input("enter amount="))
    q="select * from accounts where accno={}".format(accno)
    cur.execute(q)
    data=cur.fetchall()
    if data==[]:
        print("record not found")
    else:
        b=data[0][3]+amt
        qry="update accounts set balance={} where accno={}".format(b,accno)
        cur.execute(qry)
        obj.commit()
def withdraw():
    accno=int(input("enter account number="))
    amt=int(input("enter amount to withdraw="))
    q="select * from accounts where accno={}".format(accno)
    cur.execute(q)
    data=cur.fetchall()
    if data==[]:
        print("record not found")
    else:
        b=data[0][3]-amt
        if b<0:
            print("insufficient funds")
        else:
            if data[0][1]=='s':
                print("savings account")
                if b<1000:
                    print("withdraw less amount")
                else:
                    h="update accounts set balance={} where accno={}".format(b,accno)
        cur.execute(h)
        obj.commit()
def delete():
    while True:
        menu=int(input("enter 1)for deleting an account 2)for deleting a customer 3)to end deleting records="))
        if menu==1:
            accno=int(input("enter account number to delete="))
            q="select * from accounts where accno={}".format(accno)
            cur.execute(q)
            data=cur.fetchall()
            if data==[]:
                print("record not found")
            else:
                qry="delete from accounts where accno={}".format(accno)
                cur.execute(qry)
                obj.commit()
        elif menu==2:
            cid=input("enter customer id=")
            q="select * from customer where custid='{}'".format(cid)
            cur.execute(q)
            data=cur.fetchall()
            if data==[]:
                print("record not found")
            else:
                qry="delete from accounts where custid='{}'".format(cid)
                cur.execute(qry)
                qry="delete from customer where custid='{}'".format(cid)
                cur.execute(qry)
                obj.commit()
        elif menu==3:
            break
for x in range(5):
    a=int(input("1)to insert records in table customer\n2)to insert records in table accounts\n3)display records of accounts\n4)="))
    if a==1:
        icustomer()
    elif a==2:
        iaccounts()
    elif a==3:
        daccount()
    elif a==4:
        dcustomer()
    elif a==5:
        showall()
    elif a==6:
        searchcust()
    elif a==7:
        searchacc()
    elif a==8:
        modify()
    elif a==9:
        deposit()
    elif a==10:
        withdraw()
    elif a==11:
        delete()



            
            
            
          
    
