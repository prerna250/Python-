a=input("enter=")
b=a.split()
c=["a","e","i","o","u"]
for x in b:
    if x==c:
        print(x)
    else:
        print(a)
    
