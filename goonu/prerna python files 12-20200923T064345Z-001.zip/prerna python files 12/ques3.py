import matplotlib.pyplot as p
jan=[140,160,140,180,110]
feb=[130,200,180,180,160]
mar=[130,130,150,200,130]
apr=[190,200,170,120,110]
zones=["north","south","east","west","central"]
p.xlabel("zones")
p.ylabel("rainfall in mm")
p.title("rainfall in different regions")
p.plot(zones,jan,'r-',linewidth=2,marker='d',markersize=10,markeredgecolor='y')
p.plot(zones,feb,'b-',linewidth=2,marker='p',markersize=10,markeredgecolor='c')
p.plot(zones,mar,'y',linewidth=2,marker='o',markersize=10,markeredgecolor='b')
p.plot(zones,apr,'m--',linewidth=2,marker='s',markersize=10,markeredgecolor='r')
p.legend(zones)
p.show()
